﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

using Workshop7_WaS6_2016SOL.Employees;

namespace Workshop7_WaS6_2016SOL.Shifts
{
    public class ShiftController
    {
        private List<Shift> newShift;
        private EmployeeController employeeController;

        public ShiftController(EmployeeController empController)
        {
            employeeController = empController;
            newShift = new List<Shift>();
        }

        public void NewShedule(System.DateTime StartDate, System.DateTime EndDate)
        {
            int count = 0;
            System.DateTime aDate = StartDate;

            // indices go from 0 to 13 -- but shift numbers go from 1 to 14
            for (count = 0; count <= 13; count++)
            {
                newShift.Add(new Shift());
                newShift[count].Date = aDate;
                newShift[count].ShiftDayEve = (Shift.ShiftType)(count % 2);
                newShift[count].Number = count + 1;
                //2 shifts per day 
                if (count % 2 == 1)
                {
                    aDate = aDate.AddDays(1);
                }
            }
        }

        public bool AddEmployeeToShift(int index, Employee emp)
        {
            bool addSuccessful = false;
            addSuccessful = newShift[index].Add2Shift(emp);
            return addSuccessful;
        }
    }
}
