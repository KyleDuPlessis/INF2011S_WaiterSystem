﻿namespace Workshop7_WaS6_2016SOL.PresentationLayer
{
    partial class ShiftsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shiftsMonthCalendar = new System.Windows.Forms.MonthCalendar();
            this.calendarMessageLabel = new System.Windows.Forms.Label();
            this.eveningKeyLabel = new System.Windows.Forms.Label();
            this.dayShiftLabel = new System.Windows.Forms.Label();
            this.waitronsLabel = new System.Windows.Forms.Label();
            this.eveningShiftLabel = new System.Windows.Forms.Label();
            this.dayKeyLabel = new System.Windows.Forms.Label();
            this.waitersComboBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // shiftsMonthCalendar
            // 
            this.shiftsMonthCalendar.Location = new System.Drawing.Point(38, 43);
            this.shiftsMonthCalendar.Name = "shiftsMonthCalendar";
            this.shiftsMonthCalendar.TabIndex = 0;
           this.shiftsMonthCalendar.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.shiftsMonthCalendar_DateSelected);
            // 
            // calendarMessageLabel
            // 
            this.calendarMessageLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.calendarMessageLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendarMessageLabel.Location = new System.Drawing.Point(21, 249);
            this.calendarMessageLabel.Name = "calendarMessageLabel";
            this.calendarMessageLabel.Size = new System.Drawing.Size(332, 45);
            this.calendarMessageLabel.TabIndex = 1;
            // 
            // eveningKeyLabel
            // 
            this.eveningKeyLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.eveningKeyLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.eveningKeyLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eveningKeyLabel.Location = new System.Drawing.Point(1021, 128);
            this.eveningKeyLabel.Name = "eveningKeyLabel";
            this.eveningKeyLabel.Size = new System.Drawing.Size(50, 30);
            this.eveningKeyLabel.TabIndex = 2;
            // 
            // dayShiftLabel
            // 
            this.dayShiftLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dayShiftLabel.Location = new System.Drawing.Point(745, 128);
            this.dayShiftLabel.Name = "dayShiftLabel";
            this.dayShiftLabel.Size = new System.Drawing.Size(49, 30);
            this.dayShiftLabel.TabIndex = 3;
            this.dayShiftLabel.Text = "Day";
            // 
            // waitronsLabel
            // 
            this.waitronsLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waitronsLabel.Location = new System.Drawing.Point(853, 22);
            this.waitronsLabel.Name = "waitronsLabel";
            this.waitronsLabel.Size = new System.Drawing.Size(97, 29);
            this.waitronsLabel.TabIndex = 4;
            this.waitronsLabel.Text = "Waiters";
            // 
            // eveningShiftLabel
            // 
            this.eveningShiftLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eveningShiftLabel.Location = new System.Drawing.Point(894, 129);
            this.eveningShiftLabel.Name = "eveningShiftLabel";
            this.eveningShiftLabel.Size = new System.Drawing.Size(121, 30);
            this.eveningShiftLabel.TabIndex = 5;
            this.eveningShiftLabel.Text = "Evening";
            // 
            // dayKeyLabel
            // 
            this.dayKeyLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dayKeyLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dayKeyLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dayKeyLabel.Location = new System.Drawing.Point(800, 128);
            this.dayKeyLabel.Name = "dayKeyLabel";
            this.dayKeyLabel.Size = new System.Drawing.Size(56, 30);
            this.dayKeyLabel.TabIndex = 6;
            // 
            // waitersComboBox
            // 
            this.waitersComboBox.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waitersComboBox.FormattingEnabled = true;
            this.waitersComboBox.Location = new System.Drawing.Point(749, 54);
            this.waitersComboBox.Name = "waitersComboBox";
            this.waitersComboBox.Size = new System.Drawing.Size(322, 27);
            this.waitersComboBox.TabIndex = 7;
            // 
            // ShiftsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1259, 591);
            this.Controls.Add(this.waitersComboBox);
            this.Controls.Add(this.dayKeyLabel);
            this.Controls.Add(this.eveningShiftLabel);
            this.Controls.Add(this.waitronsLabel);
            this.Controls.Add(this.dayShiftLabel);
            this.Controls.Add(this.eveningKeyLabel);
            this.Controls.Add(this.calendarMessageLabel);
            this.Controls.Add(this.shiftsMonthCalendar);
            this.Name = "ShiftsForm";
            this.Text = "Shifts";
            this.Load += new System.EventHandler(this.ShiftsForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MonthCalendar shiftsMonthCalendar;
        private System.Windows.Forms.Label calendarMessageLabel;
        private System.Windows.Forms.Label eveningKeyLabel;
        private System.Windows.Forms.Label dayShiftLabel;
        private System.Windows.Forms.Label waitronsLabel;
        private System.Windows.Forms.Label eveningShiftLabel;
        private System.Windows.Forms.Label dayKeyLabel;
        private System.Windows.Forms.ComboBox waitersComboBox;
    }
}