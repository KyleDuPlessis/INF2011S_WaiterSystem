﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Workshop7_WaS6_2016SOL.Shifts;
using Workshop7_WaS6_2016SOL.Employees;

namespace Workshop7_WaS6_2016SOL.PresentationLayer
{
    public partial class ShiftsForm : Form
    {
        private BlockArray shiftBookings;
        private BlockArray shiftDates;
        private EmployeeController employeeController;
        private ShiftController shiftController;
        private System.DateTime startDate;
        private System.DateTime endDate;
        private bool comboInitialised = false;
        public bool shiftsFormClosed = false;

        public ShiftsForm(EmployeeController aController)
        {
            InitializeComponent();
            //Add any initialization after the InitializeComponent() call
            employeeController = aController;
            shiftController = new ShiftController(employeeController);
        }
        #region Form Events
        private void ShiftsForm_Load(object sender, EventArgs e)
        {
            ShowControls(false);
            dayShiftLabel.Text = Shift.ShiftType.Day.ToString();
            eveningShiftLabel.Text = Shift.ShiftType.Evening.ToString();
            dayKeyLabel.BackColor = Color.LightGoldenrodYellow;
            eveningKeyLabel.BackColor = Color.Turquoise;
            calendarMessageLabel.BorderStyle = BorderStyle.None;
            calendarMessageLabel.ForeColor = Color.Red;
            calendarMessageLabel.Text = "Select a week to schedule shifts";
        }
        #endregion

        #region Calendar Events

        private void shiftsMonthCalendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            System.DateTime aDate = default(System.DateTime);
            //Calendar control functions to set the Start and End date
            startDate = shiftsMonthCalendar.SelectionRange.Start;
            endDate = shiftsMonthCalendar.SelectionRange.End;

            //***Add control array, ShiftDates, to show the dates of the shifts
            shiftDates = new BlockArray(this, 50, 100, 200, 1);
            aDate = startDate;

            int intcnt = 0;
            for (intcnt = 0; intcnt <= 6; intcnt++)
            {
                shiftDates.AddNewBlock();
                shiftDates.Item(intcnt).BackColor = Color.White;
                shiftDates.Item(intcnt).Text = aDate.ToShortDateString();
                //Show date on Button
                aDate = aDate.AddDays(1);
                //**This function allows you to go to the NEXT day
            }

            //***Add a block for each slot on all the shifts – ShiftBookings control array
            shiftBookings = new BlockArray(this, 50, 100, 300, 6);
            for (intcnt = 0; intcnt <= 41; intcnt++)
            {
                shiftBookings.AddNewBlock();
                if (intcnt % 6 > 2)
                {
                    shiftBookings.Item(intcnt).BackColor = Color.Turquoise;
                }
                //*** ONLY 4 slots on a SUNDAY (2 slots per shift)
                if (intcnt == 2 || intcnt == 5)
                {
                    shiftBookings.Item(intcnt).BackColor = Color.DarkSlateGray;
                    // shiftBookings.Item(intcnt).Enabled = false;
                }
                else
                {
                    //***NB NB Add a click event dynamically to make button respond on the click of the user  NB NB 
                    shiftBookings.Item(intcnt).Click += SlotSelected;
                }
            }

            shiftsMonthCalendar.Visible = false;
            calendarMessageLabel.Visible = false;
            FillCombo();
            //workshop 7 SHIFT CONTROLLER METHOD WILL BE CALLED HERE TO SAVE NEW SHIFT TO MEMORY AND
            shiftController.NewShedule(startDate, endDate);
            //THEN WRITE TO DATABASE--LATER
            ShowControls(true);
        }
        #endregion

        #region Utility  Methods
        private void ShowControls(bool value)
        {
            waitersComboBox.Visible = value;
            waitronsLabel.Visible = value;
            dayShiftLabel.Visible = value;
            eveningShiftLabel.Visible = value;
            dayKeyLabel.Visible = value;
            eveningKeyLabel.Visible = value;
        }

        public void FillCombo()
        {
            Collection<Employee> waiters = null;
            //Find a collection of all the employees that are waitrons
            // *** add  a second  find by role method that only needs one parameter
            waiters = employeeController.FindByRole(Role.RoleType.Waiter);
            //Link the objects in the collection of waitrons to every item of the combo box
            foreach (Employee employee in waiters)
            {
                waitersComboBox.Items.Add(employee);
            }

            //Set the current display of the combobox to nothing
            waitersComboBox.SelectedIndex = -1;
            waitersComboBox.Text = "";
            comboInitialised = true;
        }
        #endregion

        #region User Defined Event Methods
        //Notice the specific signature of an event handler method
        private void SlotSelected(System.Object sender, System.EventArgs e)
        {
            Employee employee = default(Employee);
            Button button = default(Button);
            int whichShift;

            //The sender (control that was click-ed) is a button    
            button = (Button)sender;
            //Select an Employee (Waiter) from the combobox   
            //If a ToString method has been defined the combobox displayes the string returned 
            //BUT the datasource of the             
            employee = (Employee)waitersComboBox.SelectedItem;
            //Cannot book a slot if NO employee(waitron) is selected
            if (employee == null)
            {
                MessageBox.Show("First select a Waiter for the shift");
            }
            else
            {
                //***ONCE booked, the button cannot be selected again
                //***The CODE TO ADD THIS SHIFT TO A SHIFTARRAY MUST BE ADDED LATER 
                //declare a variable whichShift as an integer to indicate the shift the waiter is on
                whichShift = (Convert.ToInt32(button.Tag) / 6) * 2 + (Convert.ToInt32(button.Tag) % 6) / 3;
                if (shiftController.AddEmployeeToShift(whichShift, employee))
                {   //…..colour block;  write name &  unsubscribe to button click event)
                    button.Text = employee.Name;
                    button.BackColor = Color.Red;
                    button.Click -= SlotSelected;  //BlockArray not listening to the event any longer
                }
            }
        }

        #endregion
    }
}

