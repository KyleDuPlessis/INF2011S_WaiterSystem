﻿namespace Workshop7_WaS6_2016SOL.PresentationLayer
{
    partial class EmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.headWaitronRadioButton = new System.Windows.Forms.RadioButton();
            this.waitronRadioButton = new System.Windows.Forms.RadioButton();
            this.runnerRadioButton = new System.Windows.Forms.RadioButton();
            this.idTextBox = new System.Windows.Forms.TextBox();
            this.empIDTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.paymentTextBox = new System.Windows.Forms.TextBox();
            this.hoursTextBox = new System.Windows.Forms.TextBox();
            this.tipsTextBox = new System.Windows.Forms.TextBox();
            this.cancelButton = new System.Windows.Forms.Button();
            this.submitButton = new System.Windows.Forms.Button();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.idLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.empIDLabel = new System.Windows.Forms.Label();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.paymentLabel = new System.Windows.Forms.Label();
            this.hoursLabel = new System.Windows.Forms.Label();
            this.tipsLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // headWaitronRadioButton
            // 
            this.headWaitronRadioButton.AutoSize = true;
            this.headWaitronRadioButton.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.headWaitronRadioButton.Location = new System.Drawing.Point(80, 70);
            this.headWaitronRadioButton.Name = "headWaitronRadioButton";
            this.headWaitronRadioButton.Size = new System.Drawing.Size(126, 23);
            this.headWaitronRadioButton.TabIndex = 0;
            this.headWaitronRadioButton.TabStop = true;
            this.headWaitronRadioButton.Text = "Head Waiter";
            this.headWaitronRadioButton.UseVisualStyleBackColor = true;
            this.headWaitronRadioButton.CheckedChanged += new System.EventHandler(this.headWaitronRadioButton_CheckedChanged);
            // 
            // waitronRadioButton
            // 
            this.waitronRadioButton.AutoSize = true;
            this.waitronRadioButton.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waitronRadioButton.Location = new System.Drawing.Point(366, 70);
            this.waitronRadioButton.Name = "waitronRadioButton";
            this.waitronRadioButton.Size = new System.Drawing.Size(81, 23);
            this.waitronRadioButton.TabIndex = 1;
            this.waitronRadioButton.TabStop = true;
            this.waitronRadioButton.Text = "Waiter";
            this.waitronRadioButton.UseVisualStyleBackColor = true;
            this.waitronRadioButton.CheckedChanged += new System.EventHandler(this.waitronRadioButton_CheckedChanged);
            // 
            // runnerRadioButton
            // 
            this.runnerRadioButton.AutoSize = true;
            this.runnerRadioButton.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.runnerRadioButton.Location = new System.Drawing.Point(655, 70);
            this.runnerRadioButton.Name = "runnerRadioButton";
            this.runnerRadioButton.Size = new System.Drawing.Size(88, 23);
            this.runnerRadioButton.TabIndex = 2;
            this.runnerRadioButton.TabStop = true;
            this.runnerRadioButton.Text = "Runner";
            this.runnerRadioButton.UseVisualStyleBackColor = true;
            this.runnerRadioButton.CheckedChanged += new System.EventHandler(this.runnerRadioButton_CheckedChanged);
            // 
            // idTextBox
            // 
            this.idTextBox.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idTextBox.Location = new System.Drawing.Point(193, 146);
            this.idTextBox.Multiline = true;
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(168, 30);
            this.idTextBox.TabIndex = 10;
            // 
            // empIDTextBox
            // 
            this.empIDTextBox.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empIDTextBox.Location = new System.Drawing.Point(593, 143);
            this.empIDTextBox.Multiline = true;
            this.empIDTextBox.Name = "empIDTextBox";
            this.empIDTextBox.Size = new System.Drawing.Size(172, 30);
            this.empIDTextBox.TabIndex = 11;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameTextBox.Location = new System.Drawing.Point(193, 215);
            this.nameTextBox.Multiline = true;
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(378, 30);
            this.nameTextBox.TabIndex = 12;
            // 
            // paymentTextBox
            // 
            this.paymentTextBox.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentTextBox.Location = new System.Drawing.Point(193, 350);
            this.paymentTextBox.Multiline = true;
            this.paymentTextBox.Name = "paymentTextBox";
            this.paymentTextBox.Size = new System.Drawing.Size(168, 30);
            this.paymentTextBox.TabIndex = 13;
            // 
            // hoursTextBox
            // 
            this.hoursTextBox.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hoursTextBox.Location = new System.Drawing.Point(193, 414);
            this.hoursTextBox.Multiline = true;
            this.hoursTextBox.Name = "hoursTextBox";
            this.hoursTextBox.Size = new System.Drawing.Size(168, 30);
            this.hoursTextBox.TabIndex = 14;
            // 
            // tipsTextBox
            // 
            this.tipsTextBox.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tipsTextBox.Location = new System.Drawing.Point(193, 473);
            this.tipsTextBox.Multiline = true;
            this.tipsTextBox.Name = "tipsTextBox";
            this.tipsTextBox.Size = new System.Drawing.Size(168, 30);
            this.tipsTextBox.TabIndex = 15;
            // 
            // cancelButton
            // 
            this.cancelButton.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.Location = new System.Drawing.Point(499, 519);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(101, 29);
            this.cancelButton.TabIndex = 16;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // submitButton
            // 
            this.submitButton.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submitButton.Location = new System.Drawing.Point(684, 519);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(101, 29);
            this.submitButton.TabIndex = 17;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneTextBox.Location = new System.Drawing.Point(193, 283);
            this.phoneTextBox.Multiline = true;
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(168, 30);
            this.phoneTextBox.TabIndex = 19;
            // 
            // idLabel
            // 
            this.idLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idLabel.Location = new System.Drawing.Point(76, 149);
            this.idLabel.Name = "idLabel";
            this.idLabel.Size = new System.Drawing.Size(100, 23);
            this.idLabel.TabIndex = 20;
            this.idLabel.Text = "ID";
            // 
            // nameLabel
            // 
            this.nameLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(76, 218);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(100, 23);
            this.nameLabel.TabIndex = 21;
            this.nameLabel.Text = "Name";
            // 
            // empIDLabel
            // 
            this.empIDLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empIDLabel.Location = new System.Drawing.Point(431, 146);
            this.empIDLabel.Name = "empIDLabel";
            this.empIDLabel.Size = new System.Drawing.Size(156, 23);
            this.empIDLabel.TabIndex = 22;
            this.empIDLabel.Text = "Employee ID";
            // 
            // phoneLabel
            // 
            this.phoneLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneLabel.Location = new System.Drawing.Point(76, 286);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(100, 23);
            this.phoneLabel.TabIndex = 23;
            this.phoneLabel.Text = "Phone";
            // 
            // paymentLabel
            // 
            this.paymentLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentLabel.Location = new System.Drawing.Point(76, 353);
            this.paymentLabel.Name = "paymentLabel";
            this.paymentLabel.Size = new System.Drawing.Size(100, 23);
            this.paymentLabel.TabIndex = 24;
            this.paymentLabel.Text = "Payment";
            // 
            // hoursLabel
            // 
            this.hoursLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hoursLabel.Location = new System.Drawing.Point(76, 417);
            this.hoursLabel.Name = "hoursLabel";
            this.hoursLabel.Size = new System.Drawing.Size(100, 23);
            this.hoursLabel.TabIndex = 25;
            this.hoursLabel.Text = "Hours";
            // 
            // tipsLabel
            // 
            this.tipsLabel.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tipsLabel.Location = new System.Drawing.Point(76, 476);
            this.tipsLabel.Name = "tipsLabel";
            this.tipsLabel.Size = new System.Drawing.Size(100, 23);
            this.tipsLabel.TabIndex = 26;
            this.tipsLabel.Text = "Tips";
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(855, 519);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(101, 29);
            this.exitButton.TabIndex = 27;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // EmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 604);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.tipsLabel);
            this.Controls.Add(this.hoursLabel);
            this.Controls.Add(this.paymentLabel);
            this.Controls.Add(this.phoneLabel);
            this.Controls.Add(this.empIDLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.idLabel);
            this.Controls.Add(this.phoneTextBox);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.tipsTextBox);
            this.Controls.Add(this.hoursTextBox);
            this.Controls.Add(this.paymentTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.empIDTextBox);
            this.Controls.Add(this.idTextBox);
            this.Controls.Add(this.runnerRadioButton);
            this.Controls.Add(this.waitronRadioButton);
            this.Controls.Add(this.headWaitronRadioButton);
            this.Name = "EmployeeForm";
            this.Text = "Waitron System";
            this.Activated += new System.EventHandler(this.EmployeeForm_Activated);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_Closed);
            this.Load += new System.EventHandler(this.EmployeeForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton headWaitronRadioButton;
        private System.Windows.Forms.RadioButton waitronRadioButton;
        private System.Windows.Forms.RadioButton runnerRadioButton;
        private System.Windows.Forms.TextBox idTextBox;
        private System.Windows.Forms.TextBox empIDTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox paymentTextBox;
        private System.Windows.Forms.TextBox hoursTextBox;
        private System.Windows.Forms.TextBox tipsTextBox;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.Label idLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label empIDLabel;
        private System.Windows.Forms.Label phoneLabel;
        private System.Windows.Forms.Label paymentLabel;
        private System.Windows.Forms.Label hoursLabel;
        private System.Windows.Forms.Label tipsLabel;
        private System.Windows.Forms.Button exitButton;
    }
}